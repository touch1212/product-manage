<?php $__env->startSection('content'); ?>

<!-- resources/views/category/create.blade.php -->

<div class="max-w mx-auto mt-10 p-6 bg-white rounded-md shadow-md">
    <div class="max-w-xs w-full h-auto rounded mx-auto flex justify-center py-2">
        <img src="<?php echo e(asset($categories->image)); ?>" width="100" alt="<?php echo e($categories->name); ?>">
    </div>
  <h2 class="text-2xl font-semibold text-gray-700 mb-6">Create New Category</h2>
  <form action="<?php echo e(route('category.update',$categories->id)); ?>" method="POST" enctype="multipart/form-data" class="space-y-5">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <!-- Category Name -->
    <div>
      <label for="name" class="block text-gray-600 font-medium mb-1">Category Name <span class="text-red-500">*</span></label>
      <input type="text" id="name" name="name" placeholder="Enter category name" value="<?php echo e(old('name') ?? $categories->name); ?>"
        class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400" required />
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Category Description -->
    <div>
      <label for="description" class="block text-gray-600 font-medium mb-1">Description (optional)</label>
      <textarea id="description" name="description" rows="3" placeholder="Add a short description"
        class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 resize-none"
      ><?php echo e(old('description') ?? $categories->description); ?></textarea>
      <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
<!-- Image -->
    <div>
      <label for="image" class="block text-gray-600 font-medium mb-1">Category Image</label>
      <input type="file" id="image" name="image" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-400 resize-none" />
      <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Submit Button -->
    <div>
      <button
        type="submit"
        class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded-md transition-colors"
      >
        Update Category
      </button>
    </div>
  </form>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\product-management\resources\views/category/edit.blade.php ENDPATH**/ ?>