<?php $__env->startSection('content'); ?>
<!-- resources/views/category/index.blade.php -->

<div class="max-w-5xl mx-auto mt-10 p-6 bg-white rounded-md shadow-md">
  <div class="flex justify-between items-center mb-6">
    <h2 class="text-2xl font-semibold text-gray-700">Manage Categories</h2>
    <a href="<?php echo e(route('category.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition">
      + Add New
    </a>
  </div>

  <?php if(session('success')): ?>
    <div class="mb-4 p-3 text-green-700 bg-green-100 rounded">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>

  <table class="w-full table-auto border-collapse border border-gray-200">
    <thead>
      <tr class="bg-gray-100 text-gray-600 uppercase text-sm leading-normal">
        <th class="py-3 px-6 text-left border border-gray-300">ID</th>
        <th class="py-3 px-6 text-left border border-gray-300">Name</th>
        <th class="py-3 px-6 text-left border border-gray-300">Description</th>
        <th class="py-3 px-6 text-left border border-gray-300">Image</th>
        <th class="py-3 px-6 text-center border border-gray-300">Actions</th>
      </tr>
    </thead>
    <tbody class="text-gray-600 text-sm font-light">
      <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr class="border-b border-gray-200 hover:bg-gray-50">
        <td class="py-3 px-6 text-left border border-gray-300"><?php echo e($category->id); ?></td>
        <td class="py-3 px-6 text-left border border-gray-300"><?php echo e($category->name); ?></td>
        <td class="py-3 px-6 text-left border border-gray-300">
          <?php echo e(Str::limit($category->description, 50, '...')); ?>

        </td>
        <td class="py-3 px-6 text-left border border-gray-300">
            <img src="<?php echo e(asset($category->image)); ?>" class="w-24" alt="<?php echo e($category->name); ?>">
        </td>
        <td class="py-3 px-6 text-center border border-gray-300">
          <div class="flex item-center justify-center space-x-2">
            <a href="<?php echo e(route('category.edit', $category->id)); ?>"
               class="text-white bg-green-500 hover:bg-green-600 px-4 py-1 rounded-md shadow-md transition duration-300" title="Edit">
              <i class="fas fa-edit"></i>
            </a>
            <form action="<?php echo e(route('category.destroy', $category->id)); ?>" method="POST" onsubmit="return confirm('Are you sure?');">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="text-white bg-red-500 hover:bg-red-600 px-4 py-1 rounded-md shadow-md transition duration-300" title="Delete">
                <i class="fas fa-trash-alt"></i>
              </button>
            </form>
          </div>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr>
        <td colspan="4" class="text-center py-6 text-gray-500">No categories found.</td>
      </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\product-management\resources\views/category/index.blade.php ENDPATH**/ ?>