<?php $__env->startSection('content'); ?>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div class="bg-white p-4 rounded shadow">
                <h2 class="text-lg font-semibold">Category</h2>
                <p class="mt-2 text-3xl font-bold text-blue-500"><?php echo e(count($category)); ?></p>
            </div>
            <div class="bg-white p-4 rounded shadow">
                <h2 class="text-lg font-semibold">Product</h2>
                <p class="mt-2 text-3xl font-bold text-green-500"><?php echo e(count($product)); ?></p>
            </div>
        </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\product-management\resources\views/welcome.blade.php ENDPATH**/ ?>